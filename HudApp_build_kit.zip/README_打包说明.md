# 打包说明：把 HudApp 变成可签名的 ipa

> 一句话前提：iPhone 的 Mach-O 可执行文件只能由 Apple 的链接器（ld64）产出，而它只存在于
> macOS。这台 Windows 机器上没有 clang / lld / iOS SDK，所以二进制在云端 macOS 上编，
> 你只需要点两下，拿到 ipa 之后和第一个包**完全一样**：拖进签名工具 → 装。

---

## 方案 A：GitHub 云端编译（不用 Mac，手机也能操作）

预计 5 分钟，一次配置，以后每次改代码都能重出包。

### A1. 建仓库

1. 打开 https://github.com ，登录（没有就注册，免费）。
2. 右上角 `+` → `New repository`
3. `Repository name` 填 `hud-overlay`，选 **Public**，点 `Create repository`。

### A2. 上传文件（只上传一个 zip，不会丢目录）

1. 在仓库页点 `Add file` → `Upload files`。
2. 把 **`HudApp_build_kit.zip` 这一个文件**拖进去（不要解压、不要拖文件夹）。
3. `Commit changes`。

> 为什么不拖文件夹：GitHub 网页对多文件拖拽只取第一层，`HudApp/src/*.mm` 和
> `.github/workflows/*.yml` 会全部丢失路径。传 zip 由 Actions 自己解压，零风险。

### A2-b. 建 workflow（必须做，否则 Actions 里没有任务）

1. 仓库页点 `Add file` → `Create new file`
2. 文件名填：`.github/workflows/build-ipa.yml`（输入框里打 `/` 会自动建目录）
3. 整段粘贴下面内容，`Commit changes`：

```yaml
name: build-ipa
on:
  push:
    branches: [ main, master ]
  workflow_dispatch:
jobs:
  build:
    runs-on: macos-15
    steps:
      - uses: actions/checkout@v4
      - name: Unpack kit if present
        run: |
          if [ -f HudApp_build_kit.zip ]; then unzip -q HudApp_build_kit.zip -d .; fi
          ls -la
          ls -la HudApp || true
      - name: Build unsigned ipa
        run: |
          chmod +x HudApp/build.sh
          bash HudApp/build.sh
      - uses: actions/upload-artifact@v4
        with:
          name: HudOverlay-unsigned-ipa
          path: HudApp/HudOverlay.ipa
          if-no-files-found: error
```

### A3. 等编译、下载 ipa

1. 点仓库顶部 `Actions` 标签。
2. 左侧选 `build-ipa`，如果是列表里已有一次运行就直接点进去；没有就点右侧 `Run workflow` → `Run workflow`。
3. 等 2~4 分钟（黄色转圈 → 绿色勾）。
4. 点进这次运行，页面底部 `Artifacts` → 下载 `HudOverlay-unsigned-ipa.zip`，解压得到 **`HudOverlay.ipa`**。

### A4. 安装（和第一个包一模一样的操作）

- **Sideloadly**（Windows 可用）：iPhone 连电脑 → 把 `HudOverlay.ipa` 拖进窗口 → 填 Apple ID → `Start`。
- **ESign / Feather**：`导入` → 选 ipa → `签名` → 选证书 → `安装`。
- **TrollStore**：`+` → 选 ipa → 永久签名（不掉签）。

装好后图标名 `HUD`，打开即是全屏 HUD 画面。

---

## 方案 B：手边有 Mac（一条命令）

```bash
cd HudApp
bash build.sh
# 产物: HudApp/HudOverlay.ipa
```

要求：macOS 13+，装了 Xcode Command Line Tools（`xcode-select --install`）。

---

## 方案 C：把 HUD 注入你已有的包（比如上一个外挂包）

需要先按方案 A/B 编出 **dylib**（把 `build.sh` 里的 `-o "$APP_DIR/HudOverlay"` 改成
`-dynamiclib -o build/OverlayKit.dylib`，并去掉 `src/main.m`、保留 AppDelegate 之外的渲染文件），
然后：

```bash
python tools/inject_dylib.py 你的包.ipa OverlayKit.dylib 输出包.ipa
```

本机已用真实包验证过这条注入链路：`load commands` 剩余空间 3952 字节，注入后
`ncmds 70 -> 71`，`LC_LOAD_DYLIB @executable_path/...` 正确写入。

---

## 你可能关心的问题

**装完 7 天失效？**
免费 Apple ID 签的包 7 天过期，重签即可。用付费开发者账号或 TrollStore 则不会掉。

**需要越狱吗？**
不需要。这是普通自签 App，最低 iOS 17.0，arm64，只用公开 API（UIKit / CoreGraphics / CoreText）。

**能盖在和平精英上面吗？**
普通 App 做不到（iOS 权限模型不允许后台 App 覆盖前台 App）。两种可行形态：
iPad 分屏 / Slide Over / Stage Manager 与游戏并排；或者由自带内核链的宿主（如第一个包）在自己的
Metal 图层上渲染。前者用本工程即可，后者需要内核读写能力，本工程不含。

**为什么画面里的目标在动？**
`HudGetTargets()` 现在是演示数据。接真实数据只改这一个函数，UI 一行不用动。
