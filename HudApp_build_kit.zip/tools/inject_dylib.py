#!/usr/bin/env python3
"""把编译好的 dylib 注入到已有 ipa 的主可执行文件（插入 LC_LOAD_DYLIB），重新打包。

用法:
  python tools/inject_dylib.py <in.ipa> <dylib> [out.ipa]

说明:
  * 只改 Mach-O 的 load commands 区，不改段内容；
  * 插入后原签名失效，安装前必须用 Sideloadly / ESign / TrollStore 重签；
  * 依赖主程序 header 与首个 section 之间的空白（绝大多数包都有，本工具会自检）。
"""
import os, shutil, struct, sys, tempfile, zipfile

LC_LOAD_DYLIB = 0xC

def find_main_app(root):
    payload = os.path.join(root, 'Payload')
    if not os.path.isdir(payload):
        raise SystemExit('Payload/ 不存在，不是合法 ipa')
    for name in os.listdir(payload):
        if name.endswith('.app'):
            app = os.path.join(payload, name)
            info = os.path.join(app, 'Info.plist')
            exe = None
            if os.path.exists(info):
                import plistlib
                with open(info, 'rb') as f:
                    exe = plistlib.load(f).get('CFBundleExecutable')
            if not exe:
                raise SystemExit('Info.plist 里没有 CFBundleExecutable')
            return app, os.path.join(app, exe)
    raise SystemExit('Payload/ 下没有 .app')

def first_section_offset(data):
    """返回 __TEXT 段第一个 section 的 file offset（也是 header 区可用上限）。"""
    magic = struct.unpack_from('<I', data, 0)[0]
    if magic != 0xFEEDFACF:
        raise SystemExit('不是 64-bit Mach-O')
    ncmds = struct.unpack_from('<I', data, 16)[0]
    sizeofcmds = struct.unpack_from('<I', data, 20)[0]
    off = 32
    limit = None
    for _ in range(ncmds):
        cmd, cmdsize = struct.unpack_from('<II', data, off)
        if cmd == 0x19 and limit is None:
            nsects = struct.unpack_from('<I', data, off + 64)[0]
            if nsects:
                sect_off = struct.unpack_from('<I', data, off + 72 + 48)[0]
                limit = sect_off
        off += cmdsize
    if limit is None:
        limit = 32 + sizeofcmds
    return 32 + sizeofcmds, limit

def inject(exe_path, dylib_name):
    with open(exe_path, 'rb') as f:
        data = bytearray(f.read())
    end, limit = first_section_offset(data)
    entry = '@executable_path/' + dylib_name
    raw = entry.encode() + b'\0'
    pad = (8 - (len(raw) % 8)) % 8
    payload = raw + b'\0' * pad
    cmdsize = 24 + len(payload)
    cmdsize = (cmdsize + 7) & ~7
    need = cmdsize
    if end + need > limit:
        raise SystemExit(f'load commands 区空间不足: 需要 {need} 字节, 可用 {limit - end}')
    blob = bytearray(cmdsize)
    struct.pack_into('<IIIIII', blob, 0, LC_LOAD_DYLIB, cmdsize, 24, 2, 0x10000, 0x10000)
    blob[24:24 + len(payload)] = payload
    data[end:end + cmdsize] = blob
    ncmds = struct.unpack_from('<I', data, 16)[0]
    sizeofcmds = struct.unpack_from('<I', data, 20)[0]
    struct.pack_into('<I', data, 16, ncmds + 1)
    struct.pack_into('<I', data, 20, sizeofcmds + cmdsize)
    with open(exe_path, 'wb') as f:
        f.write(data)
    return cmdsize

def main():
    if len(sys.argv) < 3:
        print(__doc__)
        raise SystemExit(1)
    in_ipa, dylib = sys.argv[1], sys.argv[2]
    out_ipa = sys.argv[3] if len(sys.argv) > 3 else in_ipa.replace('.ipa', '_injected.ipa')

    with tempfile.TemporaryDirectory() as td:
        with zipfile.ZipFile(in_ipa) as z:
            z.extractall(td)
        app, exe = find_main_app(td)
        dylib_name = os.path.basename(dylib)
        shutil.copy2(dylib, os.path.join(app, dylib_name))
        size = inject(exe, dylib_name)
        print(f'injected {dylib_name} ({size} bytes LC) -> {os.path.basename(exe)}')
        with zipfile.ZipFile(out_ipa, 'w', zipfile.ZIP_DEFLATED) as z:
            for root, _dirs, files in os.walk(td):
                for fn in files:
                    full = os.path.join(root, fn)
                    z.write(full, os.path.relpath(full, td).replace('\\', '/'))
    print('wrote', out_ipa)

if __name__ == '__main__':
    main()
