# HudApp — 你的 ImGui 绘制源码 → iOS 17+ 可装 App

原始源码（`源码.txt`）只有绘制调用，没有宿主。这个目录把它补成完整 App：
ImGui 兼容层 + CoreGraphics 后端 + CADisplayLink 循环 + 数据接口。

## 构建（需要 macOS / Xcode Command Line Tools）

```bash
chmod +x build.sh
./build.sh
# 产物: HudOverlay.ipa（未签名）
```

没有 Mac 就用云端：

1. 把整个仓库 push 到 GitHub
2. Actions 会自动跑 `.github/workflows/build-ipa.yml`（`macos-15` runner）
3. 在 Actions → build-ipa → Artifacts 下载 `HudOverlay-unsigned-ipa`

## 安装（签名即装）

- **Sideloadly**（Windows/macOS 都能用）：拖入 `HudOverlay.ipa`，填 Apple ID，Start。免费证书 7 天。
- **ESign / Feather**：导入 ipa → 选证书 → 签名安装。
- **TrollStore**：直接把 ipa 交进去，永久签名不掉签。

## 目录

```
src/imgui.h            ImGui API 兼容层（IM_COL32 位布局与官方一致）
src/imgui_shim.cpp     兼容层实现（纯 C++）
src/hud_backend.h      C++ ↔ 渲染后端 的接口
src/render_backend.mm  CoreGraphics 几何 + UIKit 文字
src/HudView.mm         CADisplayLink 60fps 的 HUD 图层（不吞触摸）
src/hud_draw.cpp       你的源码（含 3 处修复）+ HudRenderFrame()
src/AppDelegate.mm     最小宿主窗口
src/main.m             入口
Info.plist             minos 17.0 / arm64 / 无私有框架
```

## 接真实数据

只改一个函数：

```cpp
extern "C" int HudGetTargets(HudTarget* out, int max) {
    // out[i].screen_x / screen_y / distance_m / visible
}
```

现在的实现是正弦运动的演示数据。把你自己的
世界坐标 → 屏幕坐标投影结果填进来，UI 一行都不用动。

## 已修的三处缺陷

1. 双徽章圆心距 55pt < 2×42pt → 重叠 26pt：改 74pt / −26pt
2. 图标半径 21pt 压住 label：图标 −14、文字 +21、iconScale 0.36
3. 目标点写死 `(500, 300)` 超出 390pt 屏宽：改为由数据接口给，其余元素按 `DisplaySize` 相对定位

## 注意

普通自签 App 只能在自己的窗口里绘制。要与游戏同屏，用 iPad 分屏 / Slide Over /
Stage Manager；要覆盖在游戏画面上，需要 SpringBoard 级注入或内核写入（前一个外挂包走的是后者）。
本工程不含任何取数、注入、内核代码。
