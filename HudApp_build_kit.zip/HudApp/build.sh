#!/usr/bin/env bash
# build.sh — 在 macOS（或 GitHub Actions 的 macos runner）上生成可签名的 ipa
# 用法: ./build.sh
set -euo pipefail

cd "$(dirname "$0")"

SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
MIN_IOS="17.0"
APP_DIR="build/Payload/HudOverlay.app"

rm -rf build HudOverlay.ipa
mkdir -p "$APP_DIR"

SRC=(
  src/main.m
  src/AppDelegate.mm
  src/HudView.mm
  src/render_backend.mm
  src/imgui_shim.cpp
  src/hud_draw.cpp
)

set -x
clang++ \
  -arch arm64 \
  -miphoneos-version-min=${MIN_IOS} \
  -isysroot "$SDK" \
  -fobjc-arc -O2 -std=c++17 \
  -o "$APP_DIR/HudOverlay" \
  "${SRC[@]}" \
  -framework UIKit \
  -framework Foundation \
  -framework QuartzCore \
  -framework CoreGraphics
set +x

cp Info.plist "$APP_DIR/Info.plist"
printf 'APPL????' > "$APP_DIR/PkgInfo"

# 未签名 ipa：签名交给 Sideloadly / ESign / TrollStore
(cd build && zip -qry ../HudOverlay.ipa Payload)

echo "OK -> $(pwd)/HudOverlay.ipa"
ls -lh HudOverlay.ipa
