// imgui_shim.cpp — ImGui 兼容层实现（纯 C++，无平台依赖）
#include "imgui.h"
#include "hud_backend.h"

static ImDrawList g_draw_list;
static ImGuiIO g_io;
static ImVec2 g_cursor;
static float g_font_stack[8];
static int g_font_depth = 0;
static float g_font_cur = 13.0f;

static inline void Unpack(ImU32 c, int* r, int* g, int* b, int* a) {
    *r = (int)((c >> IM_COL32_R_SHIFT) & 0xFF);
    *g = (int)((c >> IM_COL32_G_SHIFT) & 0xFF);
    *b = (int)((c >> IM_COL32_B_SHIFT) & 0xFF);
    *a = (int)((c >> IM_COL32_A_SHIFT) & 0xFF);
}

void ImDrawList::AddLine(const ImVec2& p0, const ImVec2& p1, ImU32 col, float thickness) {
    if (thickness <= 0.0f) thickness = 1.0f;
    CCHudLine(ctx, p0.x, p0.y, p1.x, p1.y, col, thickness);
}

void ImDrawList::AddCircle(const ImVec2& c, float radius, ImU32 col, int segments, float thickness) {
    (void)segments;
    if (thickness <= 0.0f) thickness = 1.0f;
    CCHudCircle(ctx, c.x, c.y, radius, col, thickness, false);
}

void ImDrawList::AddCircleFilled(const ImVec2& c, float radius, ImU32 col, int segments) {
    (void)segments;
    CCHudCircle(ctx, c.x, c.y, radius, col, 0.0f, true);
}

void ImDrawList::AddNgon(const ImVec2& c, float radius, ImU32 col, int segments, float thickness) {
    if (segments < 3) segments = 3;
    if (thickness <= 0.0f) thickness = 1.0f;
    CCHudNgon(ctx, c.x, c.y, radius, col, segments, thickness, false);
}

void ImDrawList::AddNgonFilled(const ImVec2& c, float radius, ImU32 col, int segments) {
    if (segments < 3) segments = 3;
    CCHudNgon(ctx, c.x, c.y, radius, col, segments, 0.0f, true);
}

void ImDrawList::AddConvexPolyFilled(const ImVec2* points, int num_points, ImU32 col) {
    if (!points || num_points < 3) return;
    float stack_xy[64];
    float* xy = stack_xy;
    const int max_pts = 32;
    if (num_points > max_pts) num_points = max_pts;
    for (int i = 0; i < num_points; ++i) {
        xy[i * 2 + 0] = points[i].x;
        xy[i * 2 + 1] = points[i].y;
    }
    CCHudPolyFilled(ctx, xy, num_points, col);
}

void ImDrawList::AddText(const ImVec2& pos, ImU32 col, const char* text_begin, const char* text_end) {
    if (!text_begin) return;
    char buf[512];
    size_t n = 0;
    if (text_end) {
        n = (size_t)(text_end - text_begin);
    } else {
        while (text_begin[n] && n < sizeof(buf) - 1) ++n;
    }
    if (n > sizeof(buf) - 1) n = sizeof(buf) - 1;
    for (size_t i = 0; i < n; ++i) buf[i] = text_begin[i];
    buf[n] = '\0';
    int r, g, b, a;
    Unpack(col, &r, &g, &b, &a);
    (void)r; (void)g; (void)b; (void)a;
    CCHudSetFontSize(g_font_cur);
    CCHudText(ctx, pos.x, pos.y, col, buf);
}

namespace ImGui {

ImDrawList* GetBackgroundDrawList() {
    g_draw_list.ctx = CCHudGetActiveContext();
    return &g_draw_list;
}

ImDrawList* GetWindowDrawList() {
    g_draw_list.ctx = CCHudGetActiveContext();
    return &g_draw_list;
}

ImGuiIO& GetIO() { return g_io; }

ImVec2 CalcTextSize(const char* text, const char* text_end, bool hide_text_after_double_hash, float wrap_width) {
    (void)text_end; (void)hide_text_after_double_hash; (void)wrap_width;
    float w = 0.0f, h = 0.0f;
    CCHudSetFontSize(g_font_cur);
    if (text) CCHudMeasureText(text, &w, &h);
    return ImVec2(w, h);
}

ImVec4 ColorConvertU32ToFloat4(ImU32 in) {
    int r, g, b, a;
    Unpack(in, &r, &g, &b, &a);
    return ImVec4(r / 255.0f, g / 255.0f, b / 255.0f, a / 255.0f);
}

// 即时模式：Begin/End/Dummy 不建立布局状态，只推进光标，保证源码语义可读
void Begin(const char* name, bool* p_open, int flags) {
    (void)name; (void)p_open; (void)flags;
    g_cursor = ImVec2(0.0f, 0.0f);
}

void End() {}

ImVec2 GetCursorScreenPos() { return g_cursor; }

void Dummy(const ImVec2& size) { g_cursor = ImVec2(g_cursor.x + size.x, g_cursor.y + size.y); }

void PushHudFontSize(float pt) {
    if (g_font_depth < 8) g_font_stack[g_font_depth++] = g_font_cur;
    g_font_cur = (pt > 0.0f) ? pt : 13.0f;
}

void PopHudFontSize() {
    if (g_font_depth > 0) g_font_cur = g_font_stack[--g_font_depth];
}

}  // namespace ImGui
