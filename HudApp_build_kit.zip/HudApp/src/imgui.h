// imgui.h — 兼容层：把原源码里的 ImGui 调用映射到 CoreGraphics 后端。
// 目的：源码不改一行即可编译进 iOS 17+ App，无需拖入整个 ImGui。
// 只实现源码实际用到的 API，语义与 ImGui 1.90 保持一致（尤其 IM_COL32 位布局）。
#pragma once
#include <cstddef>
#include <cmath>

typedef unsigned int ImU32;

struct ImVec2 {
    float x, y;
    ImVec2() : x(0), y(0) {}
    ImVec2(float _x, float _y) : x(_x), y(_y) {}
    inline ImVec2 operator+(const ImVec2& o) const { return ImVec2(x + o.x, y + o.y); }
    inline ImVec2 operator-(const ImVec2& o) const { return ImVec2(x - o.x, y - o.y); }
    inline ImVec2 operator*(float s) const { return ImVec2(x * s, y * s); }
};

struct ImVec4 {
    float x, y, z, w;
    ImVec4() : x(0), y(0), z(0), w(0) {}
    ImVec4(float _x, float _y, float _z, float _w) : x(_x), y(_y), z(_z), w(_w) {}
};

#ifndef IM_PI
#define IM_PI 3.14159265358979323846f
#endif

// ImGui 的位布局：A<<24 | B<<16 | G<<8 | R
#define IM_COL32_R_SHIFT 0
#define IM_COL32_G_SHIFT 8
#define IM_COL32_B_SHIFT 16
#define IM_COL32_A_SHIFT 24
#define IM_COL32(R, G, B, A) \
    (((ImU32)(A) << IM_COL32_A_SHIFT) | ((ImU32)(B) << IM_COL32_B_SHIFT) | \
     ((ImU32)(G) << IM_COL32_G_SHIFT) | ((ImU32)(R) << IM_COL32_R_SHIFT))

struct CCHudContext;

struct ImDrawList {
    CCHudContext* ctx;
    void AddLine(const ImVec2& p0, const ImVec2& p1, ImU32 col, float thickness = 1.0f);
    void AddCircle(const ImVec2& c, float radius, ImU32 col, int segments = 0, float thickness = 1.0f);
    void AddCircleFilled(const ImVec2& c, float radius, ImU32 col, int segments = 0);
    void AddNgon(const ImVec2& c, float radius, ImU32 col, int segments, float thickness = 1.0f);
    void AddNgonFilled(const ImVec2& c, float radius, ImU32 col, int segments);
    void AddConvexPolyFilled(const ImVec2* points, int num_points, ImU32 col);
    void AddText(const ImVec2& pos, ImU32 col, const char* text_begin, const char* text_end = nullptr);
};

struct ImGuiIO {
    ImVec2 DisplaySize;
    float DeltaTime = 1.0f / 60.0f;
};

namespace ImGui {
ImDrawList* GetBackgroundDrawList();
ImDrawList* GetWindowDrawList();
ImGuiIO& GetIO();
ImVec2 CalcTextSize(const char* text, const char* text_end = nullptr,
                    bool hide_text_after_double_hash = false, float wrap_width = -1.0f);
ImVec4 ColorConvertU32ToFloat4(ImU32 in);
void Begin(const char* name, bool* p_open = nullptr, int flags = 0);
void End();
ImVec2 GetCursorScreenPos();
void Dummy(const ImVec2& size);
// 非 ImGui 标准接口：为不同 UI 元素指定字号（ImGui 原生只支持全局字体）
void PushHudFontSize(float pt);
void PopHudFontSize();
}  // namespace ImGui
