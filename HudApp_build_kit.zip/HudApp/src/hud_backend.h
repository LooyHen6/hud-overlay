// hud_backend.h — C++/ObjC 之间的桥。实现在 render_backend.mm。
#pragma once
#include "imgui.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct CCHudContext CCHudContext;

CCHudContext* CCHudContextCreate(void* cg);
void CCHudContextDestroy(CCHudContext* ctx);

// 由渲染循环注入：外部不直接创建
void CCHudSetActiveContext(CCHudContext* ctx);
CCHudContext* CCHudGetActiveContext(void);
void CCHudBeginFrame(CCHudContext* ctx, float width_pt, float height_pt);
void CCHudEndFrame(CCHudContext* ctx);

void CCHudLine(CCHudContext* ctx, float x0, float y0, float x1, float y1, ImU32 col, float thickness);
void CCHudCircle(CCHudContext* ctx, float cx, float cy, float r, ImU32 col, float thickness, bool filled);
void CCHudNgon(CCHudContext* ctx, float cx, float cy, float r, ImU32 col, int segments, float thickness, bool filled);
void CCHudPolyFilled(CCHudContext* ctx, const float* xy, int count, ImU32 col);
void CCHudText(CCHudContext* ctx, float x, float y, ImU32 col, const char* text);
void CCHudMeasureText(const char* text, float* out_w, float* out_h);
void CCHudSetFontSize(float pt);
float CCHudGetFontSize(void);

#ifdef __cplusplus
}
#endif
