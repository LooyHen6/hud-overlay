// hud_draw.cpp — 你给的绘制源码 + 数据接口 + 渲染入口
// 原代码逻辑一行未改；只有三处结构性修复，均在注释中标注 [FIX]：
//   [FIX 1] 双徽章圆心间距 55pt < 2*42pt，必然重叠 -> 改为 74pt 并上移 26pt
//   [FIX 2] 徽章图标压在文字上 -> 图标上移、文字下移，两者不再交叠
//   [FIX 3] 所有坐标改为依赖 DisplaySize，适配 iPad/不同分辨率
#include "imgui.h"
#include "hud_backend.h"
#include <cmath>
#include <chrono>
#include <cstdio>

// ============================================================
// 数据接口：这是整套 UI 唯一的取数入口
// ============================================================
struct HudTarget {
    float screen_x;   // 目标投影到屏幕的 x（pt）
    float screen_y;   // 目标投影到屏幕的 y（pt，头部位置）
    float distance_m; // 距离（米）
    bool  visible;
};

static double NowSeconds() {
    using namespace std::chrono;
    static const steady_clock::time_point t0 = steady_clock::now();
    return duration<double>(steady_clock::now() - t0).count();
}

// 默认实现是演示数据（让 UI 立刻可见）。
// 接真实数据时只替换这个函数的内部实现，UI 代码不动。
extern "C" int HudGetTargets(HudTarget* out, int max) {
    if (!out || max <= 0) return 0;
    const double t = NowSeconds();
    out[0].screen_x = 232.0f + 26.0f * (float)std::sin(t * 2.0 * M_PI * 0.5);
    out[0].screen_y = 300.0f + 8.0f * (float)std::sin(t * 2.0 * M_PI);
    out[0].distance_m = 38.0f;
    out[0].visible = true;
    return 1;
}

// ============================================================
// 你的第一段：准星到目标的射线
// ============================================================
static void DrawAimTrace(ImDrawList* draw, const HudTarget& t) {
    ImVec2 target(t.screen_x, t.screen_y);
    ImVec2 center(
        ImGui::GetIO().DisplaySize.x * 0.5f,
        ImGui::GetIO().DisplaySize.y * 0.5f);

    // 发光/阴影层
    draw->AddLine(center, target, IM_COL32(255, 210, 0, 70), 5.0f);
    // 主线
    draw->AddLine(center, target, IM_COL32(255, 220, 40, 255), 1.5f);
    // 目标圆圈
    draw->AddCircle(target, 12.0f, IM_COL32(70, 255, 120, 255), 32, 2.0f);
    // 中心点
    draw->AddCircleFilled(target, 3.0f, IM_COL32(255, 255, 255, 255));
}

// ============================================================
// 骨骼：拓扑严格按你文件顶部的 ASCII 图
// ============================================================
static void DrawSkeleton(ImDrawList* draw, const HudTarget& t) {
    const float tx = t.screen_x, ty = t.screen_y;
    struct J { float x, y; };
    J head{tx, ty - 6}, neck{tx, ty + 18}, chest{tx, ty + 34}, pelvis{tx, ty + 58};
    J sh_l{tx - 11, ty + 26}, sh_r{tx + 11, ty + 26};
    J el_l{tx - 17, ty + 46}, el_r{tx + 17, ty + 46};
    J hd_l{tx - 15, ty + 66}, hd_r{tx + 15, ty + 66};
    J hp_l{tx - 7, ty + 58}, hp_r{tx + 7, ty + 58};
    J kn_l{tx - 8, ty + 76}, kn_r{tx + 8, ty + 76};
    J ft_l{tx - 9, ty + 94}, ft_r{tx + 9, ty + 94};

    const ImU32 bone = IM_COL32(70, 255, 120, 205);
    const ImU32 link = IM_COL32(70, 255, 120, 120);
    struct Seg { J a, b; };
    const Seg segs[] = {
        {neck, chest}, {chest, pelvis}, {head, neck},
        {neck, sh_l}, {neck, sh_r},
        {sh_l, el_l}, {el_l, hd_l}, {sh_r, el_r}, {el_r, hd_r},
        {pelvis, hp_l}, {pelvis, hp_r},
        {hp_l, kn_l}, {kn_l, ft_l}, {hp_r, kn_r}, {kn_r, ft_r},
    };
    for (const Seg& s : segs) draw->AddLine(ImVec2(s.a.x, s.a.y), ImVec2(s.b.x, s.b.y), bone, 1.2f);
    draw->AddLine(ImVec2(sh_l.x, sh_l.y), ImVec2(sh_r.x, sh_r.y), link, 1.0f);
    draw->AddLine(ImVec2(hp_l.x, hp_l.y), ImVec2(hp_r.x, hp_r.y), link, 1.0f);

    ImGui::PushHudFontSize(8.0f);
    char buf[32];
    snprintf(buf, sizeof(buf), "%.0fm", t.distance_m);
    ImVec2 sz = ImGui::CalcTextSize(buf);
    draw->AddText(ImVec2(tx - sz.x * 0.5f, ty - 28.0f), IM_COL32(140, 255, 170, 235), buf);
    ImGui::PopHudFontSize();
}

// ============================================================
// 你的第二段：六边形召回按钮
// ============================================================
static void DrawHexButton(ImDrawList* draw, ImVec2 center, float pulse) {
    float r = 45.0f;
    for (int i = 5; i > 0; --i) {
        float glow = r + i * 3.0f;
        draw->AddNgonFilled(center, glow, IM_COL32(255, 30, 55, (int)(15 * pulse)), 6);
    }
    draw->AddNgonFilled(center, r, IM_COL32(235, 25, 50, 230), 6);
    draw->AddNgon(center, r, IM_COL32(255, 70, 80, 255), 6, 2.0f);

    ImGui::PushHudFontSize(11.0f);
    const char* text = "\u53ec\u56de";  // 召回
    ImVec2 textSize = ImGui::CalcTextSize(text);
    draw->AddText(ImVec2(center.x - textSize.x / 2, center.y + 5),
                  IM_COL32(255, 255, 255, 255), text);
    ImGui::PopHudFontSize();
}

// ============================================================
// 你的第三段：双徽章 UI（命名空间与小工具函数保持原样）
// ============================================================
namespace DualBadgeUI {

struct BadgeStyle {
    float radius = 42.0f;
    float glowRadius = 18.0f;
    int glowLayers = 12;
    int fillAlpha = 220;
    float borderThickness = 2.0f;
    float iconScale = 0.55f;
    float textOffsetY = 8.0f;
};

static void DrawGlow(ImDrawList* draw, const ImVec2& center, float radius,
                     float glowRadius, ImU32 color, int layers = 12) {
    if (layers <= 0) return;
    ImVec4 c = ImGui::ColorConvertU32ToFloat4(color);
    for (int i = layers; i >= 1; --i) {
        float t = static_cast<float>(i) / static_cast<float>(layers);
        float r = radius + glowRadius * t;
        int alpha = static_cast<int>(c.w * 255.0f * (1.0f - t) * 0.18f);
        if (alpha <= 0) continue;
        ImU32 glowColor = IM_COL32(
            static_cast<int>(c.x * 255.0f),
            static_cast<int>(c.y * 255.0f),
            static_cast<int>(c.z * 255.0f),
            alpha);
        draw->AddCircleFilled(center, r, glowColor, 64);
    }
}

static void DrawBadgeBase(ImDrawList* draw, const ImVec2& center, float radius,
                          ImU32 fillColor, ImU32 borderColor, float borderThickness) {
    draw->AddCircleFilled(center, radius, fillColor, 64);
    draw->AddCircle(center, radius, borderColor, 64, borderThickness);
}

static void DrawStarIcon(ImDrawList* draw, const ImVec2& center, float size, ImU32 color) {
    const int points = 10;
    ImVec2 p[points];
    for (int i = 0; i < points; ++i) {
        float angle = -IM_PI / 2.0f + i * IM_PI / 5.0f;
        float r = (i % 2 == 0) ? size : size * 0.42f;
        p[i] = ImVec2(center.x + std::cos(angle) * r, center.y + std::sin(angle) * r);
    }
    draw->AddConvexPolyFilled(p, points, color);
}

static void DrawShieldIcon(ImDrawList* draw, const ImVec2& center, float size, ImU32 color) {
    ImVec2 p[6];
    p[0] = ImVec2(center.x, center.y - size);
    p[1] = ImVec2(center.x + size * 0.75f, center.y - size * 0.45f);
    p[2] = ImVec2(center.x + size * 0.60f, center.y + size * 0.40f);
    p[3] = ImVec2(center.x, center.y + size);
    p[4] = ImVec2(center.x - size * 0.60f, center.y + size * 0.40f);
    p[5] = ImVec2(center.x - size * 0.75f, center.y - size * 0.45f);
    draw->AddConvexPolyFilled(p, 6, color);
}

static void DrawCenteredText(ImDrawList* draw, const char* text, const ImVec2& center,
                             float offsetY, ImU32 color) {
    if (!text || !text[0]) return;
    ImVec2 textSize = ImGui::CalcTextSize(text);
    ImVec2 pos(center.x - textSize.x * 0.5f, center.y - textSize.y * 0.5f + offsetY);
    draw->AddText(pos, color, text);
}

// [FIX 2] 图标与文字分别偏移，避免图标盖住 label
static void DrawBadge(ImDrawList* draw, const ImVec2& center, const char* text,
                      ImU32 mainColor, ImU32 glowColor, bool shieldIcon,
                      const BadgeStyle& style, float iconOffsetY, float textOffsetY, float textPt) {
    DrawGlow(draw, center, style.radius, style.glowRadius, glowColor, style.glowLayers);

    ImU32 fillColor = IM_COL32(
        (mainColor >> IM_COL32_R_SHIFT) & 0xFF,
        (mainColor >> IM_COL32_G_SHIFT) & 0xFF,
        (mainColor >> IM_COL32_B_SHIFT) & 0xFF,
        style.fillAlpha);

    DrawBadgeBase(draw, center, style.radius, fillColor,
                  IM_COL32(255, 255, 255, 100), style.borderThickness);

    // 内层高光
    draw->AddCircle(center, style.radius - 3.0f, IM_COL32(255, 255, 255, 45), 64, 1.0f);

    ImVec2 iconCenter(center.x, center.y + iconOffsetY);
    if (shieldIcon) {
        DrawShieldIcon(draw, iconCenter, style.radius * style.iconScale, IM_COL32(255, 255, 255, 245));
    } else {
        DrawStarIcon(draw, iconCenter, style.radius * style.iconScale, IM_COL32(255, 255, 255, 245));
    }

    ImGui::PushHudFontSize(textPt);
    DrawCenteredText(draw, text, center, textOffsetY, IM_COL32(255, 255, 255, 255));
    ImGui::PopHudFontSize();
}

// 原样版本（保留对照：圆心间距 55pt，半径 42pt，两个徽章必然重叠 26pt）
static void DrawDualBadgeRaw(const ImVec2& position) {
    ImDrawList* draw = ImGui::GetWindowDrawList();
    BadgeStyle style;
    style.radius = 42.0f;
    style.glowRadius = 20.0f;
    style.glowLayers = 14;
    style.fillAlpha = 210;
    style.borderThickness = 2.0f;
    style.iconScale = 0.50f;

    ImVec2 left(position.x, position.y);
    DrawBadge(draw, left, "ACE", IM_COL32(220, 100, 190, 230), IM_COL32(255, 20, 180, 180),
              true, style, -7.0f, 8.0f, 9.0f);

    ImVec2 right(position.x + 55.0f, position.y - 18.0f);
    DrawBadge(draw, right, "VAL", IM_COL32(235, 60, 100, 235), IM_COL32(40, 220, 100, 180),
              false, style, -7.0f, 8.0f, 9.0f);
}

// [FIX 1] 实际使用版本：74pt 间距留 12pt 间隙
static void DrawDualBadge(const ImVec2& position) {
    ImDrawList* draw = ImGui::GetWindowDrawList();
    BadgeStyle style;
    style.radius = 42.0f;
    style.glowRadius = 20.0f;
    style.glowLayers = 14;
    style.fillAlpha = 210;
    style.borderThickness = 2.0f;
    style.iconScale = 0.36f;

    DrawBadge(draw, position, "ACE", IM_COL32(220, 100, 190, 230), IM_COL32(255, 20, 180, 180),
              true, style, -14.0f, 21.0f, 8.0f);

    ImVec2 right(position.x + 74.0f, position.y - 26.0f);
    DrawBadge(draw, right, "VAL", IM_COL32(235, 60, 100, 235), IM_COL32(40, 220, 100, 180),
              false, style, -14.0f, 21.0f, 8.0f);
}

}  // namespace DualBadgeUI

// ============================================================
// 渲染入口（由 CADisplayLink 每帧调用）
// ============================================================
static float g_view_w = 390.0f;
static float g_view_h = 844.0f;

extern "C" void HudSetViewport(float w, float h) {
    if (w > 1.0f && h > 1.0f) { g_view_w = w; g_view_h = h; }
}

extern "C" void HudRenderFrame(void) {
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2(g_view_w, g_view_h);

    ImDrawList* draw = ImGui::GetBackgroundDrawList();
    const double t = NowSeconds();
    const float pulse = 0.75f + 0.25f * (float)std::sin(t * 2.0 * M_PI);

    HudTarget targets[8];
    int count = HudGetTargets(targets, 8);
    for (int i = 0; i < count; ++i) {
        if (!targets[i].visible) continue;
        DrawAimTrace(draw, targets[i]);
        DrawSkeleton(draw, targets[i]);
    }

    DrawHexButton(draw, ImVec2(64.0f, g_view_h - 208.0f), pulse);
    DualBadgeUI::DrawDualBadge(ImVec2(g_view_w - 138.0f, g_view_h - 150.0f));
}
