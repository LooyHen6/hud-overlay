// render_backend.mm — CoreGraphics / UIKit 渲染后端 + 全屏 HUD 视图
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#include <string.h>
#include <stdlib.h>
#include <cmath>
#include "hud_backend.h"

struct CCHudContext {
    CGContextRef cg;
    float width;
    float height;
};

static CCHudContext* g_active = NULL;
static float g_font_size = 13.0f;

static inline UIColor* CCColor(ImU32 c) {
    CGFloat r = ((c >> IM_COL32_R_SHIFT) & 0xFF) / 255.0;
    CGFloat g = ((c >> IM_COL32_G_SHIFT) & 0xFF) / 255.0;
    CGFloat b = ((c >> IM_COL32_B_SHIFT) & 0xFF) / 255.0;
    CGFloat a = ((c >> IM_COL32_A_SHIFT) & 0xFF) / 255.0;
    return [UIColor colorWithRed:r green:g blue:b alpha:a];
}

static inline void CCApplyStrokeColor(CGContextRef cg, ImU32 c) {
    CGContextSetRGBStrokeColor(cg,
                               ((c >> IM_COL32_R_SHIFT) & 0xFF) / 255.0,
                               ((c >> IM_COL32_G_SHIFT) & 0xFF) / 255.0,
                               ((c >> IM_COL32_B_SHIFT) & 0xFF) / 255.0,
                               ((c >> IM_COL32_A_SHIFT) & 0xFF) / 255.0);
}

static inline void CCApplyFillColor(CGContextRef cg, ImU32 c) {
    CGContextSetRGBFillColor(cg,
                             ((c >> IM_COL32_R_SHIFT) & 0xFF) / 255.0,
                             ((c >> IM_COL32_G_SHIFT) & 0xFF) / 255.0,
                             ((c >> IM_COL32_B_SHIFT) & 0xFF) / 255.0,
                             ((c >> IM_COL32_A_SHIFT) & 0xFF) / 255.0);
}

static inline CCHudContext* CCEffective(CCHudContext* ctx) {
    return ctx ? ctx : g_active;
}

extern "C" {

CCHudContext* CCHudContextCreate(void* cg) {
    CCHudContext* ctx = (CCHudContext*)calloc(1, sizeof(CCHudContext));
    if (!ctx) return NULL;
    ctx->cg = (CGContextRef)cg;
    return ctx;
}

void CCHudContextDestroy(CCHudContext* ctx) {
    if (ctx) free(ctx);
}

void CCHudSetActiveContext(CCHudContext* ctx) { g_active = ctx; }
CCHudContext* CCHudGetActiveContext(void) { return g_active; }

void CCHudBeginFrame(CCHudContext* ctx, float width_pt, float height_pt) {
    if (!ctx) return;
    ctx->width = width_pt;
    ctx->height = height_pt;
    CGContextSetShouldAntialias(ctx->cg, true);
    CGContextSetAllowsAntialiasing(ctx->cg, true);
    CGContextSetLineCap(ctx->cg, kCGLineCapRound);
    CGContextSetLineJoin(ctx->cg, kCGLineJoinRound);
}

void CCHudEndFrame(CCHudContext* ctx) { (void)ctx; }

void CCHudSetFontSize(float pt) { g_font_size = pt > 0.0f ? pt : 13.0f; }
float CCHudGetFontSize(void) { return g_font_size; }

void CCHudLine(CCHudContext* ctx, float x0, float y0, float x1, float y1, ImU32 col, float thickness) {
    CCHudContext* c = CCEffective(ctx);
    if (!c || !c->cg) return;
    CCApplyStrokeColor(c->cg, col);
    CGContextSetLineWidth(c->cg, thickness);
    CGContextMoveToPoint(c->cg, x0, y0);
    CGContextAddLineToPoint(c->cg, x1, y1);
    CGContextStrokePath(c->cg);
}

void CCHudCircle(CCHudContext* ctx, float cx, float cy, float r, ImU32 col, float thickness, bool filled) {
    CCHudContext* c = CCEffective(ctx);
    if (!c || !c->cg || r <= 0.0f) return;
    CGRect rc = CGRectMake(cx - r, cy - r, r * 2.0f, r * 2.0f);
    if (filled) {
        CCApplyFillColor(c->cg, col);
        CGContextFillEllipseInRect(c->cg, rc);
    } else {
        CCApplyStrokeColor(c->cg, col);
        CGContextSetLineWidth(c->cg, thickness);
        CGContextStrokeEllipseInRect(c->cg, rc);
    }
}

static void CCBuildNgonPath(CCHudContext* c, float cx, float cy, float r, int segments) {
    for (int i = 0; i < segments; ++i) {
        double a = -M_PI_2 + (2.0 * M_PI * i) / (double)segments;
        CGFloat px = cx + (CGFloat)(cos(a) * r);
        CGFloat py = cy + (CGFloat)(sin(a) * r);
        if (i == 0) CGContextMoveToPoint(c->cg, px, py);
        else CGContextAddLineToPoint(c->cg, px, py);
    }
    CGContextClosePath(c->cg);
}

void CCHudNgon(CCHudContext* ctx, float cx, float cy, float r, ImU32 col, int segments, float thickness, bool filled) {
    CCHudContext* c = CCEffective(ctx);
    if (!c || !c->cg || segments < 3 || r <= 0.0f) return;
    CCBuildNgonPath(c, cx, cy, r, segments);
    if (filled) {
        CCApplyFillColor(c->cg, col);
        CGContextFillPath(c->cg);
    } else {
        CCApplyStrokeColor(c->cg, col);
        CGContextSetLineWidth(c->cg, thickness);
        CGContextStrokePath(c->cg);
    }
}

void CCHudPolyFilled(CCHudContext* ctx, const float* xy, int count, ImU32 col) {
    CCHudContext* c = CCEffective(ctx);
    if (!c || !c->cg || !xy || count < 3) return;
    CGContextMoveToPoint(c->cg, xy[0], xy[1]);
    for (int i = 1; i < count; ++i) CGContextAddLineToPoint(c->cg, xy[i * 2], xy[i * 2 + 1]);
    CGContextClosePath(c->cg);
    CCApplyFillColor(c->cg, col);
    CGContextFillPath(c->cg);
}

void CCHudText(CCHudContext* ctx, float x, float y, ImU32 col, const char* text) {
    CCHudContext* c = CCEffective(ctx);
    if (!c || !c->cg || !text || !text[0]) return;
    NSString* s = [NSString stringWithUTF8String:text];
    if (!s) return;
    UIFont* font = [UIFont systemFontOfSize:g_font_size];
    NSDictionary* attrs = @{
        NSFontAttributeName : font,
        NSForegroundColorAttributeName : CCColor(col),
    };
    UIGraphicsPushContext(c->cg);
    [s drawAtPoint:CGPointMake(x, y) withAttributes:attrs];
    UIGraphicsPopContext();
}

void CCHudMeasureText(const char* text, float* out_w, float* out_h) {
    if (out_w) *out_w = 0.0f;
    if (out_h) *out_h = 0.0f;
    if (!text || !text[0]) return;
    NSString* s = [NSString stringWithUTF8String:text];
    if (!s) return;
    UIFont* font = [UIFont systemFontOfSize:g_font_size];
    CGSize sz = [s sizeWithAttributes:@{NSFontAttributeName : font}];
    if (out_w) *out_w = (float)sz.width;
    if (out_h) *out_h = (float)sz.height;
}

}  // extern "C"
