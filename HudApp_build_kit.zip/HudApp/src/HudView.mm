// HudView.mm — 每帧重绘的 HUD 图层
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#include "hud_backend.h"
#import "HudView.h"

extern "C" void HudRenderFrame(void);
extern "C" void HudSetViewport(float w, float h);

@implementation HudView {
    CADisplayLink* _link;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.opaque = NO;
        self.userInteractionEnabled = NO;      // 不吞触摸
        self.clearsContextBeforeDrawing = YES;
        self.contentMode = UIViewContentModeRedraw;
        _link = [CADisplayLink displayLinkWithTarget:self selector:@selector(onTick:)];
        if (@available(iOS 15.0, *)) {
            _link.preferredFrameRateRange = CAFrameRateRangeMake(30.0f, 60.0f, 60.0f);
        }
        [_link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    }
    return self;
}

- (void)onTick:(CADisplayLink*)link {
    (void)link;
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect {
    CGContextRef cg = UIGraphicsGetCurrentContext();
    if (!cg) return;

    CCHudContext* ctx = CCHudContextCreate((void*)cg);
    if (!ctx) return;

    CCHudSetActiveContext(ctx);
    CCHudBeginFrame(ctx, (float)rect.size.width, (float)rect.size.height);
    HudSetViewport((float)rect.size.width, (float)rect.size.height);
    HudRenderFrame();
    CCHudEndFrame(ctx);
    CCHudSetActiveContext(NULL);
    CCHudContextDestroy(ctx);
}

- (void)dealloc {
    [_link invalidate];
    _link = nil;
}

@end
