// HudView.h — 对外暴露的 HUD 图层
#import <UIKit/UIKit.h>

@interface HudView : UIView
@end
